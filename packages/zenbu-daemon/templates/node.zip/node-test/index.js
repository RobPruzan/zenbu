const http = require('http');
const fs = require('fs');
const path = require('path');

let port = process.env.PORT || 3000;
const INDEX_HTML_PATH = path.join(__dirname, 'index.html');

const server = http.createServer((req, res) => {
  // Only serve index.html for the root path
  if (req.url === '/' || req.url === '/index.html') {
    fs.readFile(INDEX_HTML_PATH, (err, data) => {
      if (err) {
        console.error(`Error reading file: ${err}`);
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end('Internal Server Error');
        return;
      }
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(data);
    });
  } else {
    // Handle other paths (e.g., favicon.ico) or return 404
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Not Found');
  }
});

// Add error handler for EADDRINUSE
server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.log(`Port ${port} is already in use, trying port ${port + 1}...`);
    port++;
    setTimeout(() => {
      server.close(); // Ensure server is closed before retrying
      server.listen(port);
    }, 100); // Short delay before retry
  } else {
    console.error('Server error:', err);
    process.exit(1); // Exit on other errors
  }
});

// Add listening handler to confirm the actual port
server.on('listening', () => {
  const actualPort = server.address().port;
  console.log(`Listening: http://localhost:${actualPort}`);
  console.log(`Serving ${INDEX_HTML_PATH}`);
});

// Initial attempt to listen
server.listen(port);
